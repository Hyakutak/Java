
import javax.swing.JOptionPane;

public class Exemplo {

    public static void main(String[] args) {
         byte idade;
         idade=Byte.parseByte(JOptionPane.showInputDialog("Qual é sua idade")); 
         JOptionPane.showMessageDialog(null,"Você tem " + idade + " anos");
         System.out.print(idade);
         
         if ( idade >=18) {
             JOptionPane.showMessageDialog(null,"Você é maior de idade", "idade", 1);
         }
         else {
             JOptionPane.showMessageDialog(null,"Você é menor de idade", "idade", 1 );
         } 
         JOptionPane.showMessageDialog(null,"Você nasceu: " + ( 2020-idade ), "idade", 1 );
    }
    
}
